package com.write.Quill;

/**
 * Global variables
 * @author vbraun
 *
 */
public class Global {

	// releaseModeOEM mode hides various goodies like root support
	// public final static boolean releaseModeOEM = true;
	public final static boolean releaseModeOEM = false;

}
