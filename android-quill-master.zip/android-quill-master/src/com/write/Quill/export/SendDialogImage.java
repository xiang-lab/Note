package com.write.Quill.export;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.UUID;

import name.vbraun.view.write.Page;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.util.Log;

import com.write.Quill.R;

public abstract class SendDialogImage extends SendDialog {
	private final static String TAG = "SendDialogImage";
	

}
